Put some txt files in "words" directory.
Encoding must be UTF-8 without BOM (Byte Order Mark).
Format:
word_1=translation_1
word_2=translation_2
...
